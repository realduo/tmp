#include "GlobalVariable.h"

struct VBACurveInfo{
	long RateType;
	long RateSize;
	double RateT[RateTMax];
	double RateR[RateRMax];
};
struct VBADividendInfo{
	long DivType;
	long DivSize;
	double DivT[DivTMax];
	double DivQ[DivQMax];
};
struct VBAVolInfo{
	long VolType;
	long VolSizeT;
	long VolSizeK;
	double VolT[VolTMax];
	double VolK[VolKMax];
	double VolV[VolTMax * VolKMax];
};
struct VBAProductInfo{
    long NumofSchedule;
    long RedemDate[10];
    double PaymentDate[10];
    double Strike[10];
    double DownBarrier[10];
    double UpBarrier[10];
    double Coupon[10];
    double Dummy;
    long NumofUnderlying;
    double Base1;
    double Base2;
    long RateType1;
    long RateSize1;
    double RateT1[20];
    double RateR1[20];
    long RateType2;
    long RateSize2;
    double RateT2[20];
    double RateR2[20];
    double Div1;
    double Div2;
    long VolType1;
    long VolSizeT1;
    long VolSizeK1;
    double VolT1[20];
    double VolK1[20];
    double VolV1[20];
    long VolType2;
    long VolSizeT2;
    long VolSizeK2;
    double VolT2[20];
    double VolK2[20];
    double VolV2[400];
    double Correlation;
};