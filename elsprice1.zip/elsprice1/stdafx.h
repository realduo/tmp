// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include "GlobalVariable.h"
#include "ELSStruct.h"
#include <math.h>

// TODO: reference additional headers your program requires here
double RfInterp(long RateType, long RateSize, double *RateT, double * RateR, double T);
double VolInterp(double *volt, double *volk, double *vol, double T, double K);
double **Create2DArray(long rows, long columns);
double **Cholesky_Decomposition(double **p, long m, long n);
