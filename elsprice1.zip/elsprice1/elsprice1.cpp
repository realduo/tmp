// elsprice1.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include <iostream>
#include <math.h>
#include <time.h>
using namespace std;
#define PI 3.141592653589793238

struct vbaResult{
	double price;
	double delta1;
	double delta2;
	double gamma1;
	double gamma2;
	double vega;
	double theta;
	double duration;
};


long NumofSchedule_; long *RedemDate_; long *PaymentDate_; double *Strike_; double *DownBarrier_; double *UpBarrier_;
double *Coupon_; double Dummy_; long NumofUnderlying_; double Spot1_; double Spot2_; double Base1_; double Base2_; long RateType1_; long RateSize1_; 
double *RateT1_; double *RateR1_; long RateType2_; long RateSize2_; double *RateT2_; double *RateR2_; double Div1_;
double Div2_;  long VolType1_; long VolSizeT1_; long VolSizeK1_; double *VolT1_; double *VolK1_; double *VolV1_;
long VolType2_; long VolSizeT2_; long VolSizeK2_; double *VolT2_; double *VolK2_; double *VolV2_; double Correlation_;
long KITouched_; long SimCnt_; double Spot1_down; double Spot2_down; double Spot1_up; double Spot2_up;

#define EXPORT extern "C++" __declspec(dllexport)

double Payoff(int gubun);
double normdistrand_BoxMuller();
double PayoffCalc(double X1, double X2, long schd, long IsKI,int gubun);
bool redemtion_check(long i, double X1, double X2, int gubun);
double WorstPerform(double X1, double X2, int gubun);
long checkKI(double X1, double X2, long i, int gubun);

EXPORT vbaResult __stdcall ELSPrice(long NumofSchedule, long *Redem, long *Payment, double *Strike, double *DownB, double *UpB,
			double *Coupon, double Dummy, long NumofUnderlying, double Spot1, double Spot2, double Base1, double Base2, long RateType1, long RateSize1,
			double *RateT1, double *RateR1, long RateType2, long RateSize2, double *RateT2, double *RateR2, double Div1, double Div2,
			long VolType1, long VolSizeT1, long VolSizeK1, double *VolT1, double *VolK1, double *VolV1, long VolType2, long VolSizeT2,
			long VolSizeK2, double *VolT2, double *VolK2, double *VolV2, double Correlation, long KITouched, long SimCnt){
			vbaResult result; double price = 0.0; double price_down1 = 0.0; double price_down2 = 0.0; double price_up1 = 0.0; double price_up2 = 0.0;
			double delta1 = 0.0; double delta2 = 0.0; double gamma1 = 0.0; double gamma2 = 0.0;

	NumofSchedule_ = NumofSchedule; 	RedemDate_ = Redem; 	PaymentDate_ = Payment; 	Strike_ = Strike; 	DownBarrier_ = DownB;
	UpBarrier_ = UpB; 	Coupon_ = Coupon; 	Dummy_ = Dummy; 	NumofUnderlying_ = NumofUnderlying; 	Spot1_ = Spot1; Spot2_ = Spot2; Base1_ = Base1;
	Base2_ = Base2; 	RateType1_ = RateType1; 	RateSize1_ = RateSize1; 	RateT1_ = RateT1; 	RateR1_ = RateR1;
	RateType2_ = RateType2; 	RateSize2_ = RateSize2; 	RateT2_ = RateT2; 	RateR2_ = RateR2; 	Div1_ = Div1; 	Div2_ = Div2;
	VolType1_ = VolType1; 	VolSizeT1_ = VolSizeT1; 	VolSizeK1_ = VolSizeK1; 	VolT1_ = VolT1; 	VolK1_ = VolK1;
	VolV1_ = VolV1; 	VolType2_ = VolType2; 	VolSizeT2_ = VolSizeT2; 	VolSizeK2_ = VolSizeK2; 	VolT2_ = VolT2;
	VolK2_ = VolK2; 	VolV2_ = VolV2; 	Correlation_ = Correlation; 	KITouched_ = KITouched; 	SimCnt_ = SimCnt;
	Spot1_down = Spot1_ * 0.99; Spot2_down = Spot2_ * 0.99; Spot1_up = Spot1_ * 1.01; Spot2_up = Spot2_ * 1.01; 
	
	srand((unsigned) time(NULL));

	for(int i = 0; i < SimCnt; i++){
		price += Payoff(0); // flat
//		price_down1 += Payoff(1); // Spot1 down
//		price_down2 += Payoff(2);  // Spot2 down
//		price_up1 += Payoff(3); // Spot1 up
//		price_up2 += Payoff(4); // Spot2 up
	}
//	delta1 = (price_up1 - price_down1)/2;
//	delta2 = (price_up2 - price_down2)/2;
//	gamma1 = (price_up1 - 2 * price + price_down1);
//	gamma2 = (price_up2 - 2 * price + price_down2);
	result.price = price / (double)SimCnt;
//	result.delta1 = delta1 / (double)SimCnt;
//	result.delta2 = delta2 / (double)SimCnt;
//	result.gamma1 = gamma1 / (double)SimCnt;
//	result.gamma2 = gamma2 / (double)SimCnt;
	return result;
}

double Payoff(int gubun){
	long t = 0; double dt = 1.0/365.0;
	double R1 = 0.0, R2 = 0.0, Z1 = 0.0, Z2 = 0.0, X1 = 1.0, X2 = 1.0;
	double vol1 = 0.0; double vol2 = 0.0; double rf1 = 0.0;  double rf2 = 0.0;  double div1 = 0.0;  double div2 = 0.0; double ytm = 0.0;
	double coupon = 0.0;  double price_tmp = 0.0; long IsKI;

	IsKI = KITouched_;
	
	for(long i = 0; i < NumofSchedule_; i ++){
		while(t < RedemDate_[i]){
			R1 = normdistrand_BoxMuller();
			R2 = normdistrand_BoxMuller();
			Z1 = R1;
			Z2 = Correlation_ * R1 + sqrt(1- Correlation_ *Correlation_) * R2;
			vol1 = VolInterp(VolT1_, VolK1_, VolV1_, t, X1);
			vol2 = VolInterp(VolT2_, VolK2_, VolV2_, t, X2);
			div1 = Div1_;
			div2 = Div2_;
			rf1 = RfInterp(RateType1_,RateSize1_, RateT1_, RateR1_ , t);
			rf2 = RfInterp(RateType2_,RateSize2_, RateT2_, RateR2_ , t);
			X1 = X1 * exp((rf1 - div1 - vol1 * vol1 / 2) * dt + vol1 * Z1 * sqrt(dt));
			X2 = X2 * exp((rf2 - div2 - vol2 * vol2 / 2) * dt + vol2 * Z2 * sqrt(dt));
			//���� üũ
			IsKI = checkKI(X1, X2, i, gubun);
			
			t += 1;
		}
		ytm = RfInterp(RateType1_,RateSize1_, RateT1_, RateR1_ , t) + 0.001;
 		if(redemtion_check(i, X1, X2,gubun)){
			coupon = PayoffCalc(X1, X2, i,IsKI,gubun);
			price_tmp = (1 + coupon) * exp(-ytm * (double)(PaymentDate_[i])*dt);
			return price_tmp;
		}	
	}
	coupon = PayoffCalc(X1,X2,NumofSchedule_,IsKI,gubun);
	price_tmp = (1 + coupon) * exp(-ytm * (double)(PaymentDate_[NumofSchedule_-1])*dt);		
	return price_tmp;
}

double PayoffCalc(double X1, double X2, long schd, long IsKI, int gubun){
	double coupon = 0.0;
	double spot1 = 0.0; 
	double spot2 = 0.0;

	switch(gubun){
		case 0: // Flat
			spot1 = Spot1_; 
			spot2 = Spot2_;
			break;
		case 1: // Spot1 down
			spot1 = Spot1_down;
			spot2 = Spot2_;
			break;
		case 2: // Spot2 down
			spot1 = Spot1_;
			spot2 = Spot2_down;
			break;
		case 3: // Spot1 up
			spot1 = Spot1_up;
			spot2 = Spot2_;
			break;
		case 4: // Spot2 up
			spot1 = Spot1_;
			spot2 = Spot2_up;
			break;
	}

	//���Ⱑ �ƴ� ��
	if(schd < NumofSchedule_){
 		if(X1 * spot1 >= Base1_ * Strike_[schd] && X2 * spot2 >= Base2_ * Strike_[schd]){
			coupon = Coupon_[schd];
		}
	}
	//������ ��
	else if(schd == NumofSchedule_){
		//������ ģ ���
		if(IsKI == 1){
			//Strike ���� ���(����)
			if(X1 * spot1 >= Base1_ * Strike_[schd-1] && X2 * spot2 >= Base2_ * Strike_[schd-1]){
				coupon = Dummy_;
			}
			//Strike �Ʒ��� ���
			else{
				coupon = WorstPerform(X1, X2,gubun) - 1;
			}
		}
		//������ �� ģ ���
		else{
			//���� �踮�� ���� ���
			if(X1 * spot1 > DownBarrier_[schd-1] * Base1_ && X2 * spot2 > DownBarrier_[schd-1] * Base2_){
				coupon = Coupon_[schd-1];
			}
			//���� �踮�� �Ʒ��� ���
			else{
				coupon = WorstPerform(X1,X2, gubun) - 1;
			}
		}
	}
	return coupon;
}

bool redemtion_check(long i, double X1, double X2, int gubun){
	double spot1 = 0.0; 
	double spot2 = 0.0;

	switch(gubun){
		case 0: // Flat
			spot1 = Spot1_; 
			spot2 = Spot2_;
			break;
		case 1: // Spot1 down
			spot1 = Spot1_down;
			spot2 = Spot2_;
			break;
		case 2: // Spot2 down
			spot1 = Spot1_;
			spot2 = Spot2_down;
			break;
		case 3: // Spot1 up
			spot1 = Spot1_up;
			spot2 = Spot2_;
			break;
		case 4: // Spot2 up
			spot1 = Spot1_;
			spot2 = Spot2_up;
			break;
	}
	if(i < NumofSchedule_){
		if(X1 * spot1 >= Strike_[i] * Base1_ && X2 * spot2 >= Strike_[i] * Base2_) return true;
		return false;
	}
	else{
		return true;
	}
}

double WorstPerform(double X1, double X2, int gubun){
	double spot1 = 0.0; 
	double spot2 = 0.0;

	switch(gubun){
		case 0: // Flat
			spot1 = Spot1_; 
			spot2 = Spot2_;
			break;
		case 1: // Spot1 down
			spot1 = Spot1_down;
			spot2 = Spot2_;
			break;
		case 2: // Spot2 down
			spot1 = Spot1_;
			spot2 = Spot2_down;
			break;
		case 3: // Spot1 up
			spot1 = Spot1_up;
			spot2 = Spot2_;
			break;
		case 4: // Spot2 up
			spot1 = Spot1_;
			spot2 = Spot2_up;
			break;
	}
	if(X1 * spot1 / Base1_ > X2 * spot2 / Base2_){
		return X2 * spot2 / Base2_;
	}
	else{
		return X1 * spot1 / Base1_;
	}
}
long checkKI(double X1, double X2, long i, int gubun){
	long IsKI = 0;
	switch(gubun){
		case 0 : // Flat
			if(X1 * Spot1_ < DownBarrier_[i] * Base1_ || X2 * Spot2_ < DownBarrier_[i] * Base2_){
				IsKI = 1;
			}
			break;
		case 1 : // Spot1 down
			if(X1 * Spot1_down < DownBarrier_[i] * Base1_ || X2 * Spot2_ < DownBarrier_[i] * Base2_){
				IsKI = 1;
			}
			break;
		case 2 : // Spot2 down
			if(X1 * Spot1_ < DownBarrier_[i] * Base1_ || X2 * Spot2_down < DownBarrier_[i] * Base2_){
				IsKI = 1;
			}
			break;
		case 3 : // Spot1 up
			if(X1 * Spot1_up < DownBarrier_[i] * Base1_ || X2 * Spot2_ < DownBarrier_[i] * Base2_){
				IsKI = 1;
			}
			break;
		case 4 : // Spot2 up
			if(X1 * Spot1_ < DownBarrier_[i] * Base1_ || X2 * Spot2_up < DownBarrier_[i] * Base2_){
				IsKI = 1;
			}
			break;
	}
	return IsKI;
}

double normdistrand_BoxMuller(){
	double u1, u2, z1, z2;
	static int iset = 0;
	static double gset;
	if(iset == 0){
		do{
			u1 = rand()/(double)RAND_MAX;
			u2 = rand()/(double)RAND_MAX;
			z1 = sqrt(-2*log(u1))*cos(2*PI*u2);
			z2 = sqrt(-2*log(u1))*sin(2*PI*u2);
		}while(u1==0.0);
		gset = z2;
		iset = 1;
		return z1;
	}
	else{
		iset = 0;
		return gset;
	}
}

