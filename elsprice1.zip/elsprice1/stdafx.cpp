// stdafx.cpp : source file that includes just the standard includes
// elsprice1.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
#include <iostream>
// TODO: reference any additional headers you need in STDAFX.H
// and not in this file




double RfInterp(long RateType, long RateSize, double *RateT, double * RateR, double T){
	double Rf;
	long tind = 0;

	// Fixed case
	if (RateType == 0)
		Rf = RateR[0];

	// Term-structure case
	else if (RateType == 1){
		while (T > RateT[tind] && tind < RateSize){
			tind++;
			if (tind == RateSize)	break;
		}
		
		// nearest extrapolation
		if (tind == 0)								Rf = RateR[0];
		else if (tind == RateSize)	Rf = RateR[RateSize-1];
		else{
			// linear longerpolation
			Rf = RateR[tind-1] + 
				 (RateR[tind] - RateR[tind-1])/(RateT[tind] - RateT[tind-1]) *
				 (T-RateT[tind-1]);
		}
	}
	return Rf;
}

double VolInterp(double *volt, double *volk, double *vol, double T, double K){
	long maxT, maxK, maxV;
	double V;
	double vol1, vol2, vol11, vol12, vol21, vol22;
	long tind, kind;

	maxT = VolTMax;
	maxK = VolKMax;
	maxV = VolVMax;

	tind = 0; kind = 0;

	while((T > volt[tind]) && (tind < maxT)){
		if(tind == maxT - 1){
			break;
		}
		tind += 1;
	}
	while((K > volk[kind]) && (kind < maxK)){
		if(kind == maxK - 1){
			break;
		}
		kind += 1;
	}

	if(tind == 0){
		if(kind == 0){
			V = vol[0];
		}
		else if(kind == maxK){
			V = vol[kind - 1];
		}
		else{
			V = vol[kind - 1] + (vol[kind] - vol[kind-1]) / (volk[kind] - volk[kind-1]) * (K - volk[kind-1]);
		}
	}
	else if(tind == maxT){
		if(kind == 0){
			V = vol[maxK * (maxT - 1)];
		}
		else if(kind == maxK){
			V = vol[maxK * (maxT - 1) + kind - 1];
		}
		else{
			V = vol[maxK * (maxT - 1) + kind - 1] + (vol[maxK * (maxT - 1) + kind] - vol[maxK * (maxT - 1) + kind - 1]) / (volk[kind] - vol[kind -1]) * (K - volk[kind-1]);
		}
	}
	else{
		if(kind == 0){
			vol1 = vol[maxK * (tind - 1)];
			vol2 = vol[maxK * tind];
			V = vol1 + (vol2 - vol1) / (volt[tind] - volt[tind-1]) * (T - volt[tind-1]);
		}
		else if(kind == maxK){
			vol1 = vol[maxK * (tind - 1) + kind - 1];
			vol2 = vol[maxK * (tind) + kind - 1];
			V = vol1 + (vol2 - vol1) / (volt[tind] - volt[tind - 1]) * (T - volt[tind - 1]);
		}
		else{
			vol11 = vol[maxK * (tind - 1) + kind - 1];
			vol12 = vol[maxK * (tind - 1) + kind];
			vol21 = vol[maxK * (tind) + kind - 1];
			vol22 = vol[maxK * (tind) + kind];
			vol1 = vol11 + (vol12 - vol11) / (volk[kind] - volk[kind - 1]) * (K - volk[kind - 1]);
			vol2 = vol21 + (vol22 - vol21) / (volk[kind] - volk[kind - 1]) * (K - volk[kind - 1]);
			V = vol1 + (vol2 - vol1) / (volt[tind] - volt[tind - 1]) * (T - volt[tind - 1]);
		}
	}
	return V;
}
double **Create2DArray(long rows, long columns)
{
double **p = new double *[rows];
for (long i = 0; i < rows; i++) p[i] = new double[columns];
return p;
}

double **Cholesky_Decomposition(double **p, long m, long n)
//	Licensing: It is closed and private code.
{
long i, j, k; double temp = 0, temp2 = 0;
if (m != n)
{
exit(1);
}
//	Initialize and populate matrix L which will be the lower Cholesky
double **L = Create2DArray(m, n);
for (i = 0; i < m; i++)
for (j = 0; j < m; j++)
{
temp = 0; temp2 = 0;
if (i > j)
{
if (j > 0)
{
for (k = 1; k < j + 1; k++)
temp2 += (L[i][k - 1] * L[j][k - 1]);
}
L[i][j] = (p[i][j] - temp2) / L[j][j];
}
else if (i == j)
{
for (k = 0; k < i; k++)
temp += pow(L[i][k], 2);
L[i][j] = sqrt(p[i][j] - temp);
}
else
L[i][j] = 0;
}
return L;
}

